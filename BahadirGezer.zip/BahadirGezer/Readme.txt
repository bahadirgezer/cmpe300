## How to run the program?
Type the following command in the command line whilest in the src/ directory:
`python main.py`

The file we've provided outputs the worst case table of answer sheet 2.

# Program Structure 

The program is indepented of main.py, it is implemented like a module in the src/analysis/ directory.
The main.py file is the entry point of the program, it calls the functions in the analysis module to perform the analysis.

The input class generates the input data with two parameters. Input type and size.

The algorithm class is where our algorithm is implemented. It takes the input data and algorithm version as initial parameters.

The executor class is where the program is executed with the given algorithm version, input type, input size and case type. Case type is either average or worst case.
The whole program can  be executed through the executor class. Enums are used to define the input type, algorithm version and case type.
These enums and their values can be found in the main.py file.

