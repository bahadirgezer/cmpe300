# CMPE300 Project 1 

## How to run the python code?

Our code can be run from the terminal using the following command. 
```
python3 BahadirGezer.py
```

By default the program will run for best, worst and average cases with all 10 different input sizes, the ones given in the description. So, it runs for 30 different cases. Each case is printed out with the format specifed in the description. 
